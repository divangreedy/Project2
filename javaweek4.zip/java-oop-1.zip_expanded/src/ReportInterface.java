import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Comparator;
import java.util.List;

public interface ReportInterface {
    
     // A method to create the report and send it to the email address
     
    void generateReport(Subject subject);

    
     // A method to displays the list of students of the subject
     
    String getListOfStudents(List<Student> students);

}
