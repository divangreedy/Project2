import java.util.ArrayList;
import java.util.List;

//Amir Javad Nia


public class Classroom {
    private List<Student> students;
    private String name;

    public Classroom(String name) {
        this.name = name;
        students = new ArrayList<>();
    }

    public List<Student> getStudents() {
        return students;
    }

    public void setStudents(List<Student> students) {
        this.students = students;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
