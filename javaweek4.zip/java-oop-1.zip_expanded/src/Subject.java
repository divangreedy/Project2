import java.util.List;

public class Subject extends Classroom {

    private List<Student> students;
    private String email;
    private String name;

    public Subject(String name) {
        super(name);
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return name;
    }
}