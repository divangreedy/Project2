public class Student {

    private String name;
    private Float grade;

    public Student(String name, Float grade) {
        this.name = name;
        this.grade = grade;
    }

    public Student() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Float getGrade() {
        return grade;
    }

    public void setGrade(Float grade) {
        this.grade = grade;
    }

    @Override
    public String toString() {
        return "Student\n" +
                "\tName: " + name + '\n' +
                "\tGrade=" + grade +
                "\n";
    }
}