import java.io.BufferedReader; 

import java.io.IOException; 

import java.io.InputStreamReader; 

  

public class StudentApplication { 

    public final static BufferedReader IN = new BufferedReader(new InputStreamReader(System.in)); 

  

    public static void main(String[] args) { 

        boolean exitProgram = false; 

        String welcomeMsg = "Welcome to the grade system"; 

        System.out.println(welcomeMsg); 

        do { 

            // Load subject 

            Subject subject = getSubject(); 

            if (subject == null) continue; // If no valid subject is selected continue to next iteration and ask again 

  

            //Display subject menu and return if the user wants to change subject or exit program 

            exitProgram = subjectMenu(subject); 

  

        } while (!exitProgram); 

  

        // exit program 

        System.out.println("Closing program"); 

        try { 

            IN.close(); 

        } catch (IOException e) { 

            e.printStackTrace(); 

        } 

    } 


     // Load subject 

    private static Subject getSubject() { 

        String menuMsg = "Enter the number of the subject\n                1.Mathematics                2.Science\n                3.English"; 

        System.out.println(menuMsg); 

        Subject subject; 

        byte optionNumber = Helpers.getOptionNumber(IN); 

        switch (optionNumber) { 

            case 1: 

                subject = new Subject("Mathematics"); 

                break; 

            case 2: 

                subject = new Subject("Science"); 

                break; 

            case 3: 

                subject = new Subject("English"); 

                break; 

            default: { 

                return null; 

            } 

        } 

        try { 

            Helpers.loadFile(subject.getName(), subject); 

        } catch (IOException e) { 

            System.out.println("Couldn't locate the subject file"); 

            e.printStackTrace(); 

        } 

        return subject; 

    } 
 

     //subject menu      

    private static boolean subjectMenu(Subject subject) { 

        String menuMsg; 

        byte optionNumber; 

        // Enter Subject menu 

        boolean exitProgram = false; 

        boolean changeSubject = false; //Variable used for changing the subject 

        do { 

            menuMsg = "Subject: " + subject + "\n1. Add new student\n2. Generate and send report\n3. Change subject\n4. Exit program"; 

            System.out.println(menuMsg); 

            optionNumber = Helpers.getOptionNumber(IN); 

            switch (optionNumber) { 

                case 1: 

                    Helpers.addStudentMenu(IN, subject); 

                    break; 

                case 2: 

                    Report report = new Report(); 

                    report.generateReport(subject); 

                    break; 

                case 3: { 

                    System.out.println("Changing subject"); 

                    changeSubject = true; 

                    break; 

                } 

                case 4: 

                    exitProgram = true; 

                    break; 

            } 

        } while (!changeSubject && !exitProgram); 

        return exitProgram; 

    } 

} 