package views;

import models.Student;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ReportGUI extends JFrame {

    List<Student> students;

    /**
     * Creates a {@code VBox} layout with {@code spacing = 0} and alignment at {@code TOP_LEFT}.
     */
    public ReportGUI() {
        students = getAllStudents();
        Collections.shuffle(students);
        

        JPanel mainPanel = new JPanel();
//        mainPanel.setLayout(new GridLayout(3, 1));
        Border padding = BorderFactory.createEmptyBorder(10, 10, 10, 10);


        mainPanel.setBorder(padding);

        /**
         * Top bar
         */
        JLabel usernameLbl = new JLabel("Welcome ");
        JButton btnAddStudent = new JButton("Add a new student");
        JButton btnBack = new JButton("Back");

        JPanel topContainer = new JPanel();
        topContainer.setLayout(new GridLayout(0, 2));


        btnAddStudent.addActionListener(event -> {
            AddStudentInterface studentInterface = new AddStudentInterface();
            studentInterface.setSize(480, 480);
            studentInterface.setVisible(true);
            setVisible(false);
        });

        btnBack.addActionListener(event -> {
            MainInterface mainInterface = new MainInterface();
            mainInterface.setSize(480, 480);
            mainInterface.setVisible(true);
            setVisible(false);
        });



        JButton btnViewReport = new JButton("View Student Report");
        btnViewReport.addActionListener(event -> {
            new ReportGUI().setVisible(true);
            setVisible(false);
        });

        btnAddStudent.setPreferredSize(new Dimension(40, 10));
        btnViewReport.setPreferredSize(new Dimension(40, 10));

        topContainer.add(usernameLbl);
        topContainer.add(btnAddStudent);
        topContainer.add(btnViewReport);
        topContainer.add(btnBack);

        JPanel studentPanel = new JPanel();

        JPanel bottomPanel = new JPanel();
        topContainer.setLayout(new GridLayout(0, 2));

        JLabel scoreLabel = new JLabel("Total marks: " + 100);
        JLabel avgLabel = new JLabel("Average mark: " + 100/(students.size()+1));

        bottomPanel.add(scoreLabel);
        bottomPanel.add(avgLabel);



        mainPanel.add(topContainer);
        mainPanel.add(studentPanel);
        mainPanel.add(bottomPanel);

        add(mainPanel);

        pack();

        setSize(720, 400);
    }

    private List<Student> getAllStudents() {
        return new ArrayList<>();
    }
}
