package views;

import models.Student;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;

public class AddStudentInterface extends JFrame {

    public AddStudentInterface() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new GridLayout(0, 1));
        Border padding = BorderFactory.createEmptyBorder(10, 10, 10, 10);
        mainPanel.setBorder(padding);
        // current page label
        JLabel mainLabel = new JLabel("Department of Computer Science");
        //increase the font size label
//        mainLabel.setFont(Font.font(24));

        // Inputs for the title and price
        JLabel lblName = new JLabel("name");
        JTextField name = new JTextField();

        JLabel lblPrice = new JLabel("Marks");
        JTextField grade = new JTextField();


        JButton btnAddStudent = new JButton("Add Student");


        // Click listeners for login and register
        btnAddStudent.addActionListener(event -> {
            MainInterface mainInterface = new MainInterface();
            mainInterface.setSize(520, 480);
            // String name,  float grade
            Student student = new Student(name.getText(), Float.parseFloat(grade.getText()));
//            JavaDatabase.saveStudent(student);
            mainInterface.setVisible(true);
            setVisible(false);
        });

        JButton btnBack = new JButton("Back");
        btnBack.addActionListener(event -> {
            MainInterface mainInterface = new MainInterface();
            mainInterface.setSize(520, 480);
            mainInterface.setVisible(true);
            setVisible(false);
        });

        JPanel btnPanel = new JPanel();
        btnPanel.setLayout(new FlowLayout());
        btnPanel.add(btnAddStudent);
        btnPanel.add(btnBack);

        mainPanel.add(mainLabel);
        mainPanel.add(lblName);
        mainPanel.add(name);
        mainPanel.add(lblPrice);
        mainPanel.add(grade);
        mainPanel.add(btnPanel);

        add(mainPanel);

        setSize(420, 420);
    }
}
