package views;

import javax.swing.*;

public class SubjectGUI extends JFrame {

}
