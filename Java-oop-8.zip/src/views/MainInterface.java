package views;

import models.Student;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainInterface extends JFrame {

    List<Student> students;

    /**
     * Creates a {@code VBox} layout with {@code spacing = 0} and alignment at {@code TOP_LEFT}.
     */
    public MainInterface() {
        students = getAllStudents();
        Collections.shuffle(students);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new GridLayout(3, 1));
        Border padding = BorderFactory.createEmptyBorder(10, 10, 10, 10);


        mainPanel.setBorder(padding);

        /**
         * Top bar
         */
        JLabel usernameLbl = new JLabel("Welcome ");
        JButton btnAddStudent = new JButton("Add a new student");
        JButton btnViewReports = new JButton("View Reports");

        JPanel topContainer = new JPanel();
        topContainer.setLayout(new GridLayout(0, 2));


        btnAddStudent.addActionListener(event -> {
            AddStudentInterface studentInterface = new AddStudentInterface();
            studentInterface.setSize(480, 480);
            studentInterface.setVisible(true);
            setVisible(false);
        });

        JButton btnViewReport = new JButton("View models.Student models.Report");
        btnViewReport.addActionListener(event -> {
            new ReportGUI().setVisible(true);
            setVisible(false);
        });

        btnAddStudent.setPreferredSize(new Dimension(40, 10));
        btnViewReports.setPreferredSize(new Dimension(40, 10));
        btnViewReport.setPreferredSize(new Dimension(40, 10));

        topContainer.add(usernameLbl);
        topContainer.add(btnAddStudent);
        topContainer.add(btnViewReports);
        topContainer.add(btnViewReport);

        mainPanel.add(topContainer);

        add(mainPanel);

        pack();

        setSize(720, 400);
    }

    private List<Student> getAllStudents() {
        return new ArrayList<>();
    }
}
