package models;

import models.Student;
import models.Subject;

import java.util.List;

public interface ReportInterface {
    /*
     * A method to generate the report and send it to the email address specified in the first line of the file
     */
    void generateReport(Subject subject);

    /*
     * A method to generate the string that displays the list of students of the subject
     */
    String getListOfStudents(List<Student> students);

}
