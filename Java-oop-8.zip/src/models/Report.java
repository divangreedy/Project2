package models;

import utilities.Statistics;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Comparator;
import java.util.List;

public class Report implements ReportInterface {
    /*
     * A method to generate the report and send it to the email address specified in the first line of the file
     */
    @Override
    public void generateReport(Subject subject) {
        // Create the strings used for the report
        List<Student> students = subject.getStudents();
        String listOfStudents = getListOfStudents(students);
        String min = getMinimumGradeString(students);
        String max = getMaximumGradeString(students);
        String mostRepeated = getMostRepeatedString(students);
        String leastRepeated = getLeastRepeatedString(students);
        String average = getAverageString(students);

        System.out.print(listOfStudents);
        System.out.print(min);
        System.out.print(max);
        System.out.print(mostRepeated);
        System.out.print(leastRepeated);
        System.out.print(average);

        // Creation of the TXT
        generateTextFile(subject.toString(), listOfStudents, min, max, mostRepeated, leastRepeated, average);
        System.out.print("The txt file was created successfully\n");
    }

    /*
     * A method to generate the string that displays the list of students of the subject
     */
    @Override
    public String getListOfStudents(List<Student> students) {
        StringBuilder table = new StringBuilder();
        students.sort(Comparator.comparing(Student::getGrade).reversed());
        table.append("models.Student, Grade\n");
        for (Student student : students) {
            table.append(student.getName()).append(", ").append(student.getGrade()).append("\n");
        }

        return table.append("\n").toString();
    }

    /*
     * A method to generate the string that displays the minimum grade of the subject
     */
    private String getMinimumGradeString(List<Student> students) {
        List<Student> studentsWithMinimumGrade = Statistics.getMinimumGrade(students);
        StringBuilder sb = new StringBuilder();
        sb.append("The minimum grade is: ").append(studentsWithMinimumGrade.get(0).getGrade()).append("\n")
                .append("models.Student(s) with minimum grade: ");
        for (Student student : studentsWithMinimumGrade) {
            sb.append(student.getName()).append(", ");
        }
        sb.replace(sb.length() - 2, sb.length() - 1, "\n");
        return sb.append("\n").toString();
    }

    /*
     * A method to generate the string that displays the maximum grade of the subject
     */
    private String getMaximumGradeString(List<Student> students) {
        List<Student> studentsWithMaximumGrade = Statistics.getMaximumGrade(students);
        StringBuilder sb = new StringBuilder();
        sb.append("The maximum grade is: ").append(studentsWithMaximumGrade.get(0).getGrade()).append("\n")
                .append("models.Student(s) with maximum grade: ");
        for (Student student : studentsWithMaximumGrade) {
            sb.append(student.getName()).append(", ");
        }
        sb.replace(sb.length() - 2, sb.length() - 1, "\n");
        return sb.append("\n").toString();
    }

    /*
     * A method to generate the string that displays the most repeated grade of the subject
     */
    private String getMostRepeatedString(List<Student> students) {
        List<Student> subList = Statistics.getMostRepeated(students);
        subList.sort(Comparator.comparing(Student::getGrade).reversed());
        StringBuilder sb = new StringBuilder();
        sb.append("The most repeated grade(s) with a frequency of ").append(Statistics.getMostRepeatedFreq(students)).append(": \n");
        for (Student student : subList) {
            sb.append(" models.Student: ").append(student.getName()).append(", Grade: ").append(student.getGrade()).append("\n");
        }
        return sb.append("\n").toString();
    }

    /*
     * A method to generate the string that displays the least repeated grade of the subject
     */
    private String getLeastRepeatedString(List<Student> students) {
        List<Student> subList = Statistics.getLeastRepeated(students);
        subList.sort(Comparator.comparing(Student::getGrade).reversed());
        StringBuilder sb = new StringBuilder();
        sb.append("The least repeated grade(s) with a frequency of ").append(Statistics.getLeastRepeatedFreq(students)).append(": \n");
        for (Student student : subList) {
            sb.append(" models.Student: ").append(student.getName()).append(", Grade: ").append(student.getGrade()).append("\n");
        }
        return sb.append("\n").toString();
    }

    /*
     * A method to generate the string that displays the average grade of the subject
     */
    private String getAverageString(List<Student> students) {
        float average = Statistics.getAverage(students);
        return String.format("The average is: %.2f\n", average);
    }

    /*
     * A method to generate a txt report using the strings about the statistic modules of the subject
     */
    private void generateTextFile(String subject, String listOfStudents, String min, String max,
                                  String mostRepeated, String leastRepeated, String average) {
        File file = new File(subject + ".txt");
        FileWriter fr = null;
        try {
            fr = new FileWriter(file);
            fr.write(listOfStudents);
            fr.write(min);
            fr.write(max);
            fr.write(mostRepeated);
            fr.write(leastRepeated);
            fr.write(average);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            //close resources
            try {
                if (fr != null) {
                    fr.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}
